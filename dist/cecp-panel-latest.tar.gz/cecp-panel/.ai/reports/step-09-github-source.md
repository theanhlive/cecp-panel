RESULT: DONE

GitHub `raw.githubusercontent.com/theanhlive/cecp-panel/main` is the default install/update source; version **1.12.1-beta**.

| File | Change |
|---|---|
| `.gitignore` | Stop ignoring `dist/` so release tarballs can be tracked in git |
| `.gitattributes` | (unchanged) `*.tar.gz` already marked binary |
| `install-cecp-panel.sh` | Default `CECP_PANEL_RAW_BASE` + version 1.12.1-beta; one-liner docs |
| `lib/update.sh` | `CECP_PANEL_DEFAULT_RAW_BASE`; `update_load_mirror` defaults to GitHub; help/error text |
| `install.sh` | Version bump; customer-install error points at GitHub |
| `lib/common.sh` | Version 1.12.1-beta |
| `cecp-panel` | Version 1.12.1-beta |
| `remote-code-only-install.sh` | Default version 1.12.1-beta |
| `build-release.sh` | Prune old versioned tarballs in `dist/` after build |
| `CUSTOMER_INSTALL.md` | One-liner, pinned install, update, mirror migration, trust note |
| `README.md` | Install URL, build-release note, `update panel latest` |
| `AGENTS.md` | Section "Cài / cập nhật / phát hành: GitHub là nguồn duy nhất" + release procedure |
| `CHANGELOG.md` | Top section 1.12.1-beta + upgrade from 1.12.0 |
| `docs/RELEASE_1.12_HANDOFF.md` | Status line: distribution on GitHub 1.12.1-beta |

Not done in this step (by design): `git commit`, push, tag, `build-release.sh` run, integration test, VPS, mirror upload.
