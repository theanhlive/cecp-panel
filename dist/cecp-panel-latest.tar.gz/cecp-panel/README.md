# CECP Panel v1.12.1-beta

Standalone VPS panel (LarVPS-style). **One install** = full stack + menu.

**Spec:** [docs/products/CECP_VPS_PANEL_V2.md](../../docs/products/CECP_VPS_PANEL_V2.md)  
**Tính năng chi tiết:** [FEATURES.md](FEATURES.md) · **Thay đổi + runbook nâng cấp:** [CHANGELOG.md](CHANGELOG.md)

## Cài một lệnh (khách hàng)

Xem **[CUSTOMER_INSTALL.md](CUSTOMER_INSTALL.md)** — khách chỉ cần:

```bash
curl -fsSL https://raw.githubusercontent.com/theanhlive/cecp-panel/main/install-cecp-panel.sh | sudo bash
```

Sau cài (khuyến nghị):

```bash
cecp-panel security apply-production
cecp-panel optimize stack
cecp-panel onboard   # Cloudflare + Google Drive (tuỳ chọn)
```

Gõ lệnh nhanh: phím **Tab** gợi ý lệnh, cờ và domain (`cecp-panel ssl issue <Tab>`), có hiệu lực ở phiên SSH mới.

## Agency (từ Mac/Windows CECP)

```bash
./build-release.sh          # lint gate + dist/*.tar.gz + dist/SHA256SUMS (commit dist/ lên main)
SSH_KEY=~/.ssh/KEY ./deploy-safe.sh root@VPS_IP --with-check
```

Kiểm thử (cần Docker):

```bash
bash tests/lint.sh                  # bash -n + shellcheck + check_truncation.py
bash tests/integration/run.sh       # AlmaLinux 9 + systemd, cài panel và chạy scenario.sh
```

## Features

| Menu | Commands |
|------|----------|
| Domains | `site add/remove/list/duplicate`, SFTP per site, `protect-admin` (basic auth / IP allowlist), `site auth` (whole site) |
| Agency | `site staging` + `staging-push` (rollback), safe `wp update` / `auto-update` / `rollback`, `site limits` (CPU/RAM per site), `php config`, `db export/import/shell/slow-report`, `status --json` |
| Updates | `update all` (OS + wp-cli + every WordPress site + panel, with rollback) + `update enable-cron`; new `site add --wp` turns on cache auto-purge + WordPress auto-update by default |
| SSL | Let's Encrypt webroot or Cloudflare DNS-01 (`--dns`, `--wildcard`, subdomain sites reuse the wildcard), HTTPS + HTTP/2 template, `ssl hsts` |
| DNS | Cloudflare A records (`/etc/cecp-panel/credentials.env`) |
| Backup | restic → Google Drive / local / sftp, tiered retention, `verify`, `restore --live` with rollback |
| Security | vhost hardening, Cloudflare real IP, fail2ban (+nginx deny), SSH harden/port/key-only/repair, MariaDB bind, Redis ACL, `apply-production`, `check`, `fix-perms` |
| Performance | FastCGI cache (tracking-param-free key, per-site TTL, auto-purge on content change, per-site/URL purge), Cloudflare HTML edge cache (`cf edge-cache`), HTTP/2, Redis+WP, OPcache JIT, BBR, MariaDB tune, brotli, bench, report |
| Media | Per-site opt-in: on-upload resize/compress/WebP (+ optional AVIF) + daily cron batch; nginx serves WebP/AVIF by `Accept` |
| System | auto swap, disk/log cleanup, logrotate, weekly maintain cron |
| Monitor | services/sites/SSL/disk/backup every 5 min, auto-restart, alerts on change (`monitor enable`) |
| Notify | Telegram, Discord, signed JSON webhook → n8n ([docs/WEBHOOK_N8N.md](docs/WEBHOOK_N8N.md)) |
| Agent | heartbeat → CECP API (`docs/infrastructure/CECP_PANEL_AGENT_INTEGRATION.md`) |

## Quick start (lab)

```bash
cp templates/credentials.env.example /etc/cecp-panel/credentials.env
cecp-panel security apply-production
cecp-panel optimize stack
cecp-panel dns point test2.theanhlive.com
cecp-panel site add test2.theanhlive.com --wordpress
cecp-panel optimize redis-wp test2.theanhlive.com
cecp-panel ssl issue test2.theanhlive.com
cecp-panel backup setup
cecp-panel backup enable-cron
```

## Nâng cấp panel trên VPS đã cài

```bash
cecp-panel update panel latest
# VPS còn mirror cũ trong panel.env: cecp-panel update mirror https://raw.githubusercontent.com/theanhlive/cecp-panel/main
# rồi làm theo runbook trong CHANGELOG.md (apply-production, site rebuild-vhost --all, ...)
```

## Docs

- [NOTIFICATIONS.md](docs/NOTIFICATIONS.md) — cảnh báo qua Telegram / Zalo Bot / Discord / n8n, chọn loại thông báo
- [INCIDENT_RESPONSE.md](docs/INCIDENT_RESPONSE.md) — website bị hack: quét, làm sạch, đổi bí mật, ngăn lây chéo
- [CLOUDFLARE_DNS.md](docs/CLOUDFLARE_DNS.md) — trỏ domain qua Cloudflare (DNS, SSL, khoá IP gốc) — runbook cho người & AI Agent ([AGENTS.md](AGENTS.md))
- [MEDIA_OPTIMIZE.md](docs/MEDIA_OPTIMIZE.md) — per-site image optimize (opt-in)
- [VPS_BACKUP_GDRIVE.md](../../docs/infrastructure/VPS_BACKUP_GDRIVE.md)
- [CECP_PANEL_PRODUCT_PRIORITIES.md](../../docs/products/CECP_PANEL_PRODUCT_PRIORITIES.md)
