    root {{DOCROOT}};
    index index.php index.html;

    access_log /var/log/nginx/{{DOMAIN}}-access.log cecp;
    error_log  /var/log/nginx/{{DOMAIN}}-error.log;

    # A symlink planted by this site's (compromised) code must not let nginx serve another site's
    # files, or anything else on the server: follow only links owned like their target.
    disable_symlinks if_not_owner from=$document_root;

    # Follows PHP post_max_size (nginx default is 1m: media uploads failed with 413).
    client_max_body_size {{BODY_SIZE}};

    include {{HEADERS}};
{{ADMIN_GUARD}}
    # Certificate issuance/renewal must work even when the whole site is behind basic auth.
    location ^~ /.well-known/acme-challenge/ {
        auth_basic off;
        default_type "text/plain";
        try_files $uri =404;
    }

    # Deny rules come first: nginx uses the FIRST matching regex location, so anything after
    # "location ~ \.php$" would never apply (uploaded .php files would execute).
    location ~* /(?:uploads|files)/.*\.(?:php[0-9]?|phtml|phar)$ { deny all; }
    location ~* ^/wp-includes/[^/]+\.php$ { deny all; }
    location ~* ^/wp-admin/includes/ { deny all; }
    location = /wp-config.php { deny all; }
    location = /xmlrpc.php { deny all; }
    location ~ /\.(?!well-known) { deny all; }
    location ~* \.(?:env|git|svn|htaccess|htpasswd|sql|bak|log|ini|sh|swp)$ { deny all; }
    # Backup/migration plugin archives: on Apache their .htaccess protects them, nginx ignores
    # .htaccess, so the whole site + database would be downloadable by anyone guessing the name.
    location ~* ^/wp-content/(?:ai1wm-backups|updraft|backups-dup-(?:lite|pro)|backup-db|backupwordpress-[^/]*|wpvividbackups|backuply|uploads/(?:backwpup-[^/]*|wp-migrate-db|wp-staging))/ { deny all; }
    # Database dumps and editor/backup leftovers (wp-config.php.save, wp-config.php~, *.orig ...).
    location ~* (?:\.(?:wpress|wpstg|sql\.(?:gz|zip|bz2|xz)|dump|orig|old|save|swo)|~)$ { deny all; }

    # wp-cron.php: with the server cron (cecp-panel wp cron) only the loopback call may run it, in
    # this site's own PHP-FPM pool; public hits were a free way to burn CPU. Never page-cached.
    location = /wp-cron.php {
{{CRON_ACCESS}}
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_pass unix:{{PHP_SOCK}};
        fastcgi_read_timeout {{FCGI_TIMEOUT}};
    }

    # Login form: tight per-IP rate limit (bots get 429 and then a fail2ban ban); never cached.
    location = /wp-login.php {
        limit_req zone=cecp_login burst=10 nodelay;
        limit_conn cecp_conn 20;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_pass unix:{{PHP_SOCK}};
        fastcgi_read_timeout {{FCGI_TIMEOUT}};
    }

    location / {
        # Dynamic HTML only — never rate-limit static assets (browsers load 50+ in parallel).
        limit_req zone=cecp_general burst=50 nodelay;
        limit_conn cecp_conn 80;
        try_files $uri $uri/ /index.php?$args;
    }

    # JPEG/PNG: prefer the AVIF/WebP sidecar the browser accepts (Vary: Accept for caches).
    set $cecp_img_avif {{IMG_AVIF}};
    location ~* ^(?<cecp_img>.+)\.(?:jpe?g|png)$ {
        expires 30d;
        access_log off;
        types {
            image/avif avif;
            image/webp webp;
            image/jpeg jpg jpeg;
            image/png png;
        }
        add_header Vary Accept;
        add_header Cache-Control "public, max-age=2592000";
        include {{HEADERS}};
        try_files $cecp_img$cecp_img_avif $cecp_img$cecp_webp_ext $uri =404;
    }

    location ~* \.(?:gif|ico|css|js|mjs|woff2?|ttf|otf|eot|svg|webp|avif|mp4|webm|pdf)$ {
        expires 30d;
        access_log off;
        add_header Cache-Control "public, max-age=2592000";
        include {{HEADERS}};
    }

    location ~ \.php$ {
        limit_req zone=cecp_general burst=50 nodelay;
        limit_conn cecp_conn 80;
        try_files $uri =404;
        fastcgi_split_path_info ^(.+\.php)(/.+)$;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_pass unix:{{PHP_SOCK}};
        fastcgi_read_timeout {{FCGI_TIMEOUT}};
        fastcgi_buffers 16 16k;
        fastcgi_buffer_size 32k;

        # Micro-cache anonymous pages; bypass logged-in users, carts, previews, search, admin.
        set $cecp_skip_cache 0;
        if ($http_cookie ~* "wordpress_logged_in|wp-postpass|woocommerce_items_in_cart|woocommerce_cart_hash|comment_author") {
            set $cecp_skip_cache 1;
        }
        if ($request_method !~ ^(GET|HEAD)$) { set $cecp_skip_cache 1; }
        if ($args ~* "(^|&)(preview[a-z_]*|customize_changeset[a-z_]*|add-to-cart|wc-ajax|s)=") {
            set $cecp_skip_cache 1;
        }
        if ($request_uri ~* "^/(wp-admin|wp-login\.php|cart|checkout|my-account|wc-api)") {
            set $cecp_skip_cache 1;
        }
        fastcgi_cache_bypass $cecp_skip_cache;
        fastcgi_no_cache $cecp_skip_cache;
        fastcgi_cache CECP_WP;
        # open_file_cache would keep serving a purged (deleted) cache file from its cached fd.
        open_file_cache off;
        fastcgi_cache_valid 200 301 302 {{CACHE_TTL}};
        fastcgi_cache_valid 404 1m;
        add_header X-CECP-Cache $upstream_cache_status;
        include {{HEADERS}};
    }
