# Hướng dẫn cho AI Agent — CECP Panel

CECP Panel là bộ script bash (+ Python nhỏ) cài và quản lý VPS web (nginx, PHP-FPM, MariaDB,
Redis, WordPress, Let's Encrypt, backup restic → Google Drive). CLI: `cecp-panel`, chạy bằng root.

> **Phiên bản hiện tại 2.0.0 (kênh stable); GitHub là nguồn cài/cập nhật duy nhất.** Lộ trình 2.0:
> [docs/PLAN_2.0.md](docs/PLAN_2.0.md) ([ADR-0001](docs/adr/0001-release-readiness.md)); kiểm thử VPS lab trước RC:
> [docs/LAB_CHECKLIST.md](docs/LAB_CHECKLIST.md). Bàn giao 1.12 (lưu trữ): [docs/archive/RELEASE_1.12_HANDOFF.md](docs/archive/RELEASE_1.12_HANDOFF.md).

## Triển khai trên VPS (vận hành)

| Việc | Tài liệu bắt buộc đọc trước |
|---|---|
| **Website bị hack** / nghi nhiễm mã độc (quét, làm sạch, đổi mật khẩu, ngăn tái nhiễm) | [docs/INCIDENT_RESPONSE.md](docs/INCIDENT_RESPONSE.md) |
| Trỏ domain qua **Cloudflare** (DNS, proxy, SSL mode, khoá IP gốc) | [docs/CLOUDFLARE_DNS.md](docs/CLOUDFLARE_DNS.md) |
| Cài panel cho khách | [CUSTOMER_INSTALL.md](CUSTOMER_INSTALL.md) |
| Nâng cấp panel trên VPS đang chạy | mục "Nâng cấp từ …" của phiên bản mới nhất trong [CHANGELOG.md](CHANGELOG.md) |
| Tối ưu ảnh theo site | [docs/MEDIA_OPTIMIZE.md](docs/MEDIA_OPTIMIZE.md) |
| Tune / chứng minh tải theo domain (audit, capacity, loadtest, rollback); Cloudflare token cho agent (`tools/cf-agent.sh`, máy vận hành) | [docs/SITE_TUNING.md](docs/SITE_TUNING.md), [docs/CLOUDFLARE_AGENT_TOKEN.md](docs/CLOUDFLARE_AGENT_TOKEN.md) |
| Thông báo Telegram / Zalo / Discord, chọn loại thông báo | [docs/NOTIFICATIONS.md](docs/NOTIFICATIONS.md) |
| Webhook n8n (JSON ký HMAC) | [docs/WEBHOOK_N8N.md](docs/WEBHOOK_N8N.md) |

Quy tắc vận hành:
- Không in/log/commit bí mật (Cloudflare token, mật khẩu DB/WordPress/SFTP, restic password).
  Panel đã chỉ hiện mật khẩu ra terminal, không ghi `panel.log` — giữ nguyên như vậy.
- Sự cố bảo mật: chạy `cecp-panel security scan --all` và báo kết quả trước khi sửa/xoá bất cứ gì.
- Lệnh phá huỷ (`site remove`, `backup restore --live`, `db import`, `site staging-push`,
  `security cf-only on --force`, `dns ssl-mode` trên zone có subdomain khác) cần chủ VPS đồng ý.
- Sau mỗi thay đổi: `cecp-panel security check` và `cecp-panel status` để xác nhận.

## Sửa code (phát triển)

- Kiểm tra nhanh (bắt buộc trước khi commit): `bash tests/lint.sh` (bash -n + shellcheck + check_truncation).
- Test tích hợp (cần Docker, AlmaLinux 9 + systemd): `bash tests/integration/run.sh`; kịch bản trong
  `tests/integration/scenario.sh` — thêm `check` cho hành vi mới.
- Phiên bản nằm ở 5 chỗ, phải giống nhau (build-release.sh kiểm tra): `cecp-panel`, `lib/common.sh`,
  `install.sh`, `install-cecp-panel.sh`, `remote-code-only-install.sh`.
- Mỗi thay đổi hành vi ghi vào `CHANGELOG.md` (tiếng Việt), kèm mục "Nâng cấp từ …" nếu VPS cũ
  cần chạy lệnh để áp dụng.
- Quy ước code: `set -euo pipefail`; mọi input (domain, URL, số) qua `validate_*` trong
  `lib/common.sh`; file env chỉ nạp bằng `secure_source`; bí mật không nằm trong argv (dùng
  `curl -K <(...)`, `mysql --defaults-extra-file`, stdin); root không ghi vào thư mục của site
  (dùng `runuser -u SITE_USER`); nginx đổi cấu hình qua `nginx_test_and_reload` (tự rollback).
- Template nginx/PHP ở `templates/`; vhost được render lại bằng `cecp-panel site rebuild-vhost --all`.

## Cài / cập nhật / phát hành: GitHub là nguồn duy nhất

| Việc | Lệnh / URL |
|---|---|
| Khách cài VPS mới | `curl -fsSL https://raw.githubusercontent.com/theanhlive/cecp-panel/main/install-cecp-panel.sh \| sudo bash` |
| Nâng cấp panel | `cecp-panel update panel latest` |
| VPS còn mirror cũ trong `panel.env` | một lần: `cecp-panel update mirror https://raw.githubusercontent.com/theanhlive/cecp-panel/main` |

**Quy trình phát hành (agent, chi tiết + ký minisign thủ công: [docs/RELEASING.md](docs/RELEASING.md)):** `bash tests/lint.sh` → `bash tests/integration/run.sh` (0 failed) → (bản RC/chính thức) [docs/LAB_CHECKLIST.md](docs/LAB_CHECKLIST.md) → bump phiên bản ở 5 chỗ + `CHANGELOG.md` → `./build-release.sh [--channel stable|beta]` → chủ repo ký `dist/<kênh>/SHA256SUMS` ngoại tuyến → commit code + `dist/` → push `main` → tag `vX.Y.Z-beta` trên commit cuối → kiểm tra raw URL + sha256 → nâng cấp từng VPS một.

Mirror CDN isharevn cũ (**đã ngừng phân phối**) — chỉ dùng GitHub raw `main`.
