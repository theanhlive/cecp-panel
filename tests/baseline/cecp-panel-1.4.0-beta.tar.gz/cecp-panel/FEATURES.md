# CECP Panel v1.4 — tính năng (bán hosting / khách tự cài)

**Ưu tiên:** Bảo mật → WordPress → Tốc độ → LarVPS parity (dần)

## Bảo mật (v1.4)

- Firewall baseline (firewalld/ufw), fail2ban full jails:
  - `sshd`, `nginx-limit-req`, `nginx-http-auth`, `cecp-wordpress` (+ `nginx-botsearch` nếu filter có)
- Rate limit / limit conn nginx
- Headers: X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy
- `server_tokens off`, PHP `expose_php=Off`
- Chặn xmlrpc, `.env`, `.git`, PHP trong uploads
- User + DB + PHP pool riêng, `open_basedir`, `disable_functions`
- SFTP chroot
- SSH: harden (`PermitRootLogin prohibit-password`), key-only, đổi port
- MariaDB: bind `127.0.0.1`, xóa anonymous/test/remote root
- Snippet SSL params + HSTS (`/etc/nginx/snippets/cecp-ssl-params.conf`)
- Audit log: `/var/log/cecp-panel/audit.log` + `panel.log`
- `cecp-panel security apply-production` — one-shot
- `cecp-panel security check` — self-check

## WordPress

- `site add DOMAIN --wordpress`
- Auto harden + system cron
- `wp harden|optimize|cron|status`
- Redis object cache: `optimize redis-wp DOMAIN`

## Hiệu năng (v1.4)

- gzip + open_file_cache + worker_processes auto
- FastCGI cache 5m (guest; bypass login/cart/checkout/Woo/preview)
- FastCGI purge: `optimize purge [all|DOMAIN]`
- PHP-FPM `ondemand` + OPcache + **JIT** (`optimize opcache`)
- Redis secure (bind localhost, password, maxmemory theo RAM, allkeys-lru)
- MariaDB tune **theo RAM**
- Kernel BBR + FQ + swappiness=10
- Brotli origin (nếu package có) / gợi ý Cloudflare
- WebP via webp-express
- Bench TTFB: `optimize bench DOMAIN`
- Full stack: `optimize stack`

## System (RAM / ổ đĩa)

- **Swap tự động** theo RAM (`system ensure-swap` / chạy lúc cài)
- **Dọn disk:** journal, nginx/php/cecp logs, dnf/apt cache, tmp, nginx cache, WP transients (khi disk ≥ 70%)
- **Cron hàng tuần:** Chủ nhật 03:30 UTC — `system maintain`
- Cấu hình: `/etc/cecp-panel/system.env`

## Lệnh nhanh sau cài / nâng cấp

```bash
cecp-panel security apply-production
cecp-panel optimize stack
cecp-panel site add example.com --wordpress
cecp-panel optimize redis-wp example.com
cecp-panel ssl issue example.com
cecp-panel security check
```

## Chưa có (roadmap)

- ModSecurity optional, File Manager, staging
- OpenLiteSpeed dual-stack
- Telegram/Discord notify
- WebUI agency (CECP control plane)
- HTTP/3 QUIC (phụ thuộc build nginx)
