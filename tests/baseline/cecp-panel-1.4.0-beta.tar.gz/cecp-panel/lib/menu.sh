#!/usr/bin/env bash
set -euo pipefail

menu_banner() {
  echo "========================================================================="
  echo "  CECP Panel v$CECP_PANEL_VERSION — VPS management (standalone)"
  echo "-------------------------------------------------------------------------"
  if command -v free &>/dev/null; then
    free -h | awk '/Mem:/ {print "  RAM: "$3" / "$2}'
  fi
  df -h / 2>/dev/null | awk 'NR==2 {print "  Disk: "$3" used / "$2" ("$5")"}'
  echo "-------------------------------------------------------------------------"
}

menu_domain() {
  while true; do
    echo ""
    echo "== Domain management =="
    echo " 1) List domains"
    echo " 2) Add domain (+ optional WordPress)"
    echo " 3) Remove domain"
    echo " 4) Duplicate domain"
    echo " 5) SFTP info"
    echo " 6) Set SFTP password"
    echo " 0) Back"
    read -r -p "Choice: " c
    case "$c" in
      1) site_list ;;
      2)
        read -r -p "Domain: " dom
        [[ -z "$dom" ]] && continue
        read -r -p "WordPress? (y/n): " wp
        site_add "$dom" "$wp"
        ;;
      3)
        read -r -p "Domain: " dom
        [[ -z "$dom" ]] && continue
        read -r -p "Confirm delete $dom? (yes): " ok
        [[ "$ok" == "yes" ]] && site_remove "$dom"
        ;;
      4)
        read -r -p "Source domain: " s
        read -r -p "New domain: " d
        [[ -n "$s" && -n "$d" ]] && site_duplicate "$s" "$d"
        ;;
      5)
        read -r -p "Domain: " dom
        [[ -n "$dom" ]] && site_sftp_info "$dom"
        ;;
      6)
        read -r -p "Domain: " dom
        [[ -n "$dom" ]] && site_sftp_password "$dom"
        ;;
      0) break ;;
    esac
  done
}

menu_ssl() {
  while true; do
    echo ""
    echo "== SSL (Let's Encrypt) =="
    echo " 1) List  2) Add  3) Remove  4) Renew  5) Status"
    echo " 0) Back"
    read -r -p "Choice: " c
    case "$c" in
      1) ssl_list ;;
      2) read -r -p "Domain: " dom; [[ -n "$dom" ]] && ssl_issue_for_domain "$dom" ;;
      3) read -r -p "Domain: " dom; [[ -n "$dom" ]] && ssl_remove_for_domain "$dom" ;;
      4) ssl_renew_all ;;
      5) ssl_status ;;
      0) break ;;
    esac
  done
}

menu_dns() {
  while true; do
    echo ""
    echo "== Cloudflare DNS =="
    echo " 1) List A records (default zone)"
    echo " 2) Add/update A record (subdomain → this VPS)"
    echo " 3) Point site domain to this VPS"
    echo " 0) Back"
    read -r -p "Choice: " c
    case "$c" in
      1) dns_list_a ;;
      2)
        read -r -p "Name (test2 or fqdn): " n
        read -r -p "Proxied? (y/n): " px
        local ip
        ip="$(curl -4 -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')"
        [[ "$px" =~ ^[nN] ]] && dns_add_a "$n" "$ip" false || dns_add_a "$n" "$ip" true
        ;;
      3)
        read -r -p "Domain: " dom
        [[ -n "$dom" ]] && dns_point_site "$dom"
        ;;
      0) break ;;
    esac
  done
}

menu_security() {
  while true; do
    echo ""
    echo "== Security =="
    echo " 1) fail2ban status"
    echo " 2) Firewall status"
    echo " 3) SSH settings"
    echo " 4) SSH harden (prohibit-password root)"
    echo " 5) Disable SSH password login (keys only)"
    echo " 6) Change SSH port"
    echo " 7) Fail2Ban full jails"
    echo " 8) MariaDB bind localhost"
    echo " 9) Apply production profile (all-in-one)"
    echo "10) Security self-check"
    echo " 0) Back"
    read -r -p "Choice: " c
    case "$c" in
      1) security_fail2ban_status ;;
      2) security_firewall_status ;;
      3) security_ssh_show ;;
      4) security_ssh_harden ;;
      5)
        read -r -p "Disable password SSH? Ensure key works! (yes): " ok
        [[ "$ok" == "yes" ]] && security_apply_ssh_key_only
        ;;
      6)
        read -r -p "New SSH port [2222]: " p
        security_ssh_set_port "${p:-2222}"
        ;;
      7) security_fail2ban_full ;;
      8) security_mariadb_bind_local ;;
      9) security_apply_production ;;
      10) security_self_check ;;
      0) break ;;
    esac
  done
}

menu_wordpress() {
  while true; do
    echo ""
    echo "== WordPress =="
    echo " 1) Harden site"
    echo " 2) Optimize (harden+cron+db)"
    echo " 3) System cron (disable wp-cron web)"
    echo " 4) Status"
    echo " 0) Back"
    read -r -p "Domain: " d
    [[ -z "$d" || "$d" == "0" ]] && { [[ "$d" == "0" ]] && break; continue; }
    read -r -p "Action (1-4): " c
    case "$c" in
      1) wp_harden_site "$d" ;;
      2) wp_optimize_site "$d" ;;
      3) wp_install_system_cron "$d" ;;
      4) wp_status_site "$d" ;;
    esac
  done
}

menu_perf() {
  while true; do
    echo ""
    echo "== Performance =="
    echo " 1) Global nginx (gzip, cache zone, rate limit)"
    echo " 2) Optimize one site (vhost + pool + WP)"
    echo " 3) Install/secure Redis"
    echo " 4) Redis object cache for WordPress site"
    echo " 5) Tune MariaDB (by RAM)"
    echo " 6) OPcache + JIT"
    echo " 7) Kernel BBR + sysctl"
    echo " 8) Purge FastCGI cache (all)"
    echo " 9) Full stack optimize (1-7)"
    echo "10) Bench TTFB (domain)"
    echo "11) Brotli (origin)"
    echo "12) WebP (WordPress plugin)"
    echo " 0) Back"
    read -r -p "Choice: " c
    case "$c" in
      1) optimize_nginx_global ;;
      2)
        read -r -p "Domain: " d
        [[ -n "$d" ]] && optimize_site "$d"
        ;;
      3) optimize_install_redis ;;
      4)
        read -r -p "Domain: " d
        [[ -n "$d" ]] && optimize_redis_wp "$d"
        ;;
      5) optimize_mariadb_tune ;;
      6) optimize_opcache_jit ;;
      7) optimize_kernel_bbr ;;
      8) optimize_purge_cache all ;;
      9) optimize_stack ;;
      10)
        read -r -p "Domain: " d
        optimize_bench "${d:-}"
        ;;
      11) optimize_brotli ;;
      12)
        read -r -p "Domain: " d
        [[ -n "$d" ]] && optimize_webp "$d"
        ;;
      0) break ;;
    esac
  done
}

menu_system() {
  while true; do
    echo ""
    echo "== System (RAM / disk) =="
    echo " 1) VPS info"
    echo " 2) Auto swap (theo RAM VPS)"
    echo " 3) Add swap file (manual GB)"
    echo " 4) Disk + log cleanup"
    echo " 5) Full tune (swap + clean + weekly cron)"
    echo " 6) Enable weekly maintain cron"
    echo " 0) Back"
    read -r -p "Choice: " c
    case "$c" in
      1) system_info ;;
      2) system_swap_ensure ;;
      3)
        read -r -p "Size GB [2]: " gb
        system_swap_add "${gb:-2}"
        ;;
      4) system_disk_clean ;;
      5) system_tune ;;
      6) system_enable_maintain_cron ;;
      0) break ;;
    esac
  done
}

menu_php() {
  while true; do
    echo ""
    echo "== PHP =="
    echo " 1) List versions / per-site"
    echo " 2) Install PHP (81/82/83 via Remi)"
    echo " 3) Set site PHP version"
    echo " 0) Back"
    read -r -p "Choice: " c
    case "$c" in
      1) php_list_versions ;;
      2)
        read -r -p "Version (81/82/83): " v
        [[ -n "$v" ]] && php_install_version "$v"
        ;;
      3)
        read -r -p "Domain: " d
        read -r -p "PHP version: " v
        [[ -n "$d" && -n "$v" ]] && php_set_site_version "$d" "$v"
        ;;
      0) break ;;
    esac
  done
}

menu_update() {
  while true; do
    echo ""
    echo "== Updates =="
    echo " 1) Check versions"
    echo " 2) Update panel (from mirror)"
    echo " 3) Set update mirror URL"
    echo " 4) Update nginx"
    echo " 5) Update mariadb"
    echo " 6) Update php (system)"
    echo " 7) Update all OS packages"
    echo " 0) Back"
    read -r -p "Choice: " c
    case "$c" in
      1) update_check ;;
      2) update_panel ;;
      3)
        read -r -p "Mirror base URL: " u
        [[ -n "$u" ]] && update_mirror_set "$u"
        ;;
      4) update_component nginx ;;
      5) update_component mariadb ;;
      6) update_component php ;;
      7) update_component all ;;
      0) break ;;
    esac
  done
}

menu_backup() {
  while true; do
    echo ""
    echo "== Backup (Google Drive) =="
    echo " 1) Setup  2) Status  3) Run all  4) List snapshots"
    echo " 5) Policy  6) Daily cron  7) Prune now"
    echo " 0) Back"
    read -r -p "Choice: " c
    case "$c" in
      1) backup_setup ;;
      2) backup_status ;;
      3) backup_run_all ;;
      4) backup_list ;;
      5) backup_policy_show ;;
      6) backup_enable_cron ;;
      7) backup_apply_retention ;;
      0) break ;;
    esac
  done
}

menu_main() {
  while true; do
    menu_banner
    echo " 1) Domains (add/remove/duplicate/SFTP)"
    echo " 2) SSL (Let's Encrypt)"
    echo " 3) Cloudflare DNS"
    echo " 4) Backup (Google Drive)"
    echo " 5) Security (fail2ban/SSH/production)"
    echo " 6) WordPress (harden/optimize)"
    echo " 7) Performance (cache/gzip/redis)"
    echo " 8) System (info/swap/logs)"
    echo " 9) MariaDB hardening"
    echo "10) PHP versions"
    echo "11) Updates (OS / panel)"
    echo "12) CECP agent"
    echo "13) Quick status"
    echo " 0) Exit"
    echo "========================================================================="
    read -r -p "Choice [0]: " choice
    choice="${choice:-0}"
    case "$choice" in
      1) menu_domain ;;
      2) menu_ssl ;;
      3) menu_dns ;;
      4) menu_backup ;;
      5) menu_security ;;
      6) menu_wordpress ;;
      7) menu_perf ;;
      8) menu_system ;;
      9) mysql_secure_basics ;;
      10) menu_php ;;
      11) menu_update ;;
      12) agent_install; agent_status ;;
      13) show_status ;;
      0) exit 0 ;;
      *) echo "Unknown option" ;;
    esac
  done
}

show_status() {
  system_info
  echo "--- Services ---"
  for s in nginx mariadb fail2ban php-fpm; do
    systemctl is-active --quiet "$s" 2>/dev/null && echo "  [OK] $s" || echo "  [--] $s"
  done
  site_list
}
